const list = document.getElementById('materialsList');
const count = document.getElementById('itemCount');
const picker = document.getElementById('newMaterial');
const custom = document.getElementById('customMaterial');
const toast = document.getElementById('toast');
let nextId = 1;
let items = [];

function notify(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove('show'), 2400);
}
picker.addEventListener('change', () => {
  custom.hidden = picker.value !== 'مادة أخرى';
  if (!custom.hidden) custom.focus();
});

function addMaterial(name) {
  const clean = (name || '').trim();
  if (!clean) { notify('اكتب اسم المادة أولاً'); return; }
  items.push({id: nextId++, material: clean, selected: true, category:'', width:'', length:'', count:'', height:''});
  render();
  notify('تمت إضافة مادة ' + clean);
}
document.getElementById('addMaterial').addEventListener('click', () => {
  const name = picker.value === 'مادة أخرى' ? custom.value : picker.value;
  addMaterial(name);
  if (picker.value === 'مادة أخرى') custom.value = '';
});
function field(item, key, label, placeholder, extra='') {
  return `<div class="field ${extra}"><label for="${key}-${item.id}">${label} <span class="muted">(اختياري)</span></label><input id="${key}-${item.id}" data-key="${key}" data-id="${item.id}" value="${escapeAttr(item[key] || '')}" placeholder="${placeholder}" inputmode="text"></div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function escapeAttr(s){return escapeHtml(s);}
function render() {
  count.textContent = items.length;
  if (!items.length) {
    list.innerHTML = '<div class="empty-state">لا توجد مواد بعد 🌿<br>اختر المادة من الأعلى واضغط «إضافة مادة».</div>';
    return;
  }
  list.innerHTML = items.map((item,index) => `
    <article class="material-card ${item.selected?'':'unselected'}" data-card="${item.id}">
      <div class="card-head">
        <input class="card-check" type="checkbox" aria-label="تحديد ${escapeAttr(item.material)}" data-select="${item.id}" ${item.selected?'checked':''}>
        <div class="card-title">المادة ${index+1} — ${escapeHtml(item.material)}<div class="card-index">رقم المادة: ${index+1}</div></div>
        <button class="delete-btn" data-delete="${item.id}">حذف</button>
      </div>
      <input class="card-material" data-key="material" data-id="${item.id}" value="${escapeAttr(item.material)}" aria-label="اسم المادة" placeholder="اسم المادة">
      <div class="fields-grid">
        ${field(item,'category','الصنف','مثال: نوع أو قياس')}
        ${field(item,'width','العرض','العرض')}
        ${field(item,'length','الطول','الطول')}
        ${field(item,'count','العدد','العدد')}
        ${field(item,'height','ارتفاع المجاري','الارتفاع','wide')}
      </div>
      <div class="card-note">يمكنك ترك أي حقل فارغًا — لن يظهر في نص المشاركة.</div>
    </article>`).join('');
}
list.addEventListener('input', e => {
  const el = e.target;
  if (!el.dataset.id || !el.dataset.key) return;
  const item = items.find(x => x.id === Number(el.dataset.id));
  if (item) item[el.dataset.key] = el.value;
  if (el.dataset.key === 'material') {
    const title = el.closest('.material-card').querySelector('.card-title');
    const index = items.findIndex(x => x.id === item.id) + 1;
    title.innerHTML = `المادة ${index} — ${escapeHtml(item.material || 'بدون اسم')}<div class="card-index">رقم المادة: ${index}</div>`;
  }
});
list.addEventListener('change', e => {
  if (!e.target.dataset.select) return;
  const item = items.find(x => x.id === Number(e.target.dataset.select));
  if (item) item.selected = e.target.checked;
  e.target.closest('.material-card').classList.toggle('unselected', !e.target.checked);
});
list.addEventListener('click', e => {
  const id = e.target.dataset.delete;
  if (!id) return;
  items = items.filter(x => x.id !== Number(id));
  render();
  notify('تم حذف المادة');
});
document.getElementById('selectAll').addEventListener('click', () => {
  items.forEach(x => x.selected = true); render(); notify('تم تحديد جميع المواد');
});
document.getElementById('deselectAll').addEventListener('click', () => {
  items.forEach(x => x.selected = false); render(); notify('تم إلغاء تحديد المواد');
});
document.getElementById('clearAll').addEventListener('click', () => {
  if (!items.length) { notify('القائمة فارغة بالفعل'); return; }
  if (confirm('هل تريد مسح جميع المواد والحقول؟ لا يمكن التراجع عن ذلك.')) {
    items = []; render(); notify('تم مسح القائمة بالكامل');
  }
});
function buildShareText() {
  const chosen = items.filter(x => x.selected);
  if (!chosen.length) return '';
  const blocks = chosen.map(item => {
    const lines = [`【 ${item.material.trim() || 'مادة بدون اسم'} 】`];
    const fields = [['الصنف',item.category],['العرض',item.width],['الطول',item.length],['العدد',item.count],['ارتفاع المجاري',item.height]];
    fields.forEach(([label,value]) => { if (String(value || '').trim()) lines.push(`${label}: ${String(value).trim()}`); });
    return lines.join('\n');
  });
  return `— 🧰 طلب المواد —\n\n${blocks.join('\n\n━━━━━━━━━━━━\n\n')}\n\nالمطوّر: محمد الفاتح`;
}
async function copyText() {
  const text = buildShareText();
  if (!text) { notify('حدّد مادة واحدة على الأقل للمشاركة'); return; }
  try {
    await navigator.clipboard.writeText(text);
    notify('تم نسخ نص المواد المحددة');
  } catch (_) {
    const area = document.createElement('textarea');
    area.value = text; area.style.position='fixed'; area.style.opacity='0';
    document.body.appendChild(area); area.select();
    const ok = document.execCommand('copy'); area.remove();
    notify(ok ? 'تم نسخ نص المشاركة' : 'تعذّر النسخ؛ جرّب المشاركة مباشرة');
  }
}
document.getElementById('copyText').addEventListener('click', copyText);
document.getElementById('shareAll').addEventListener('click', async () => {
  const text = buildShareText();
  if (!text) { notify('حدّد مادة واحدة على الأقل للمشاركة'); return; }
  if (navigator.share) {
    try { await navigator.share({title:'طلب المواد', text}); }
    catch (e) { if (e.name !== 'AbortError') notify('لم تكتمل المشاركة'); }
  } else {
    await copyText();
    notify('تم نسخ النص؛ الصقه في واتساب أو تيليجرام');
  }
});
addMaterial('مجاري');
addMaterial('رواصير');
addMaterial('بيليات');
